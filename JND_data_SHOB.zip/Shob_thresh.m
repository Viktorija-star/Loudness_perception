close all
clear all 
clc

Th1 = load('./JND_data_SHOB/STR_CMR_BMLD_3AFC_shob_26102020_1.dat');
Th2 = load('./JND_data_SHOB/STR_CMR_BMLD_3AFC_shob_26102020_2.dat');
Th3 = load('./JND_data_SHOB/STR_CMR_BMLD_3AFC_shob_26102020_3.dat');

Th1 = sortrows(Th1,[3,2]);
Th2 = sortrows(Th2,[3,2]);
Th3 = sortrows(Th3,[3,2]);

average = cat(3, Th1, Th2, Th3);
average = sum(average,3);
average = average/3;

save('JND_data_SHOB\threshold_shob.mat');